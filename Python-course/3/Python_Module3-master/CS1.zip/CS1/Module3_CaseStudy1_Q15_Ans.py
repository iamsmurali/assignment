# Give example of fsum and sum function of math library
import math
list1=[1,2,3,4,5,6,7,8,9]
print sum(list1)

# range(10)
print math.fsum(range(10))
print sum(range(10))

# Integer list
arr = [1, 4, 6]
print math.fsum(arr)

# Floating point list
arr = [1.5, 2.4, 3.05]
print math.fsum(arr)