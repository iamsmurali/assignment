import Customer


class Order:
    def __init__(self, productname, productcode):
        self.productname = productname
        self.productcode = productcode
