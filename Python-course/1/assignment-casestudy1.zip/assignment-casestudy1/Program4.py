input = input("Enter a String: ")

digit = letter = 0
for i in input:
    if i.isdigit():
        digit = digit + 1
    elif i.isalpha():
        letter = letter + 1
    else:
        pass

print("Letters: ", letter)
print("Digits: ", digit)
