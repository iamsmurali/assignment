li = [12,24,35,70,88,120,155]
li = [x for x in li if x%5!=0 and x%7!=0]
print (li)