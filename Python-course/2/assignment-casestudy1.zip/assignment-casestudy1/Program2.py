input = input("Enter a String: ")

print("Alphabetically sorted string: ", ''.join(sorted(input)))