a = [4, 7, 3, 2, 5, 9]

for i in a:
    print(i, a.index(i))
