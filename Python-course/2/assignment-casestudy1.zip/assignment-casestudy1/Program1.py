
input = input("Enter a number: ")

try:
    number = int(input)

    print("Factor of a number associated with Odd/Even")
    for i in range(1, number + 1):
        if (number % i == 0):
            if (i % 2 == 0):
                print(i, "even")
            else:
                print(i, "odd")

except ValueError:
    print(input, "is not a number")
