input = input("Enter a number: ")

try:
    value = int(input)
    if input == str(input)[::-1]:
        print(input, "is is Palindrome number")
    else:
        print(input, "is not Palindrome number") 

except ValueError:
    print(input, "is not a number")