string = input("Enter a String: ")

print(string[::-1])
