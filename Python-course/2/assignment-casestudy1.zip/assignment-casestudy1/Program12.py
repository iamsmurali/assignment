string = input("Enter a String: ")

conve_string = sorted(set(string))

for i in conve_string:
    cout = 0
    for j in string:
        if i == j:
            cout = cout + 1
    print(i, cout)
