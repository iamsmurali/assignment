nums = set([1,1,2,3,3,3,4,4])
print(len(nums))

'Ans is 4